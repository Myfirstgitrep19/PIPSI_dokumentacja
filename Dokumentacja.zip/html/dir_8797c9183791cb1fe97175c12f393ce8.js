var dir_8797c9183791cb1fe97175c12f393ce8 =
[
    [ "20200604215126_AddGameToDb.cs", "20200604215126___add_game_to_db_8cs.html", [
      [ "AddGameToDb", "class_game_list_m_v_c_1_1_migrations_1_1_add_game_to_db.html", "class_game_list_m_v_c_1_1_migrations_1_1_add_game_to_db" ]
    ] ],
    [ "20200604215126_AddGameToDb.Designer.cs", "20200604215126___add_game_to_db_8_designer_8cs.html", [
      [ "AddGameToDb", "class_game_list_m_v_c_1_1_migrations_1_1_add_game_to_db.html", "class_game_list_m_v_c_1_1_migrations_1_1_add_game_to_db" ]
    ] ],
    [ "20200605183804_Contacts.cs", "20200605183804___contacts_8cs.html", [
      [ "Contacts", "class_game_list_m_v_c_1_1_migrations_1_1_contacts.html", "class_game_list_m_v_c_1_1_migrations_1_1_contacts" ]
    ] ],
    [ "20200605183804_contacts.Designer.cs", "20200605183804__contacts_8_designer_8cs.html", [
      [ "Contacts", "class_game_list_m_v_c_1_1_migrations_1_1_contacts.html", "class_game_list_m_v_c_1_1_migrations_1_1_contacts" ]
    ] ],
    [ "ApplicationDbContextModelSnapshot.cs", "_application_db_context_model_snapshot_8cs.html", [
      [ "ApplicationDbContextModelSnapshot", "class_game_list_m_v_c_1_1_migrations_1_1_application_db_context_model_snapshot.html", "class_game_list_m_v_c_1_1_migrations_1_1_application_db_context_model_snapshot" ]
    ] ]
];