var namespace_game_list_m_v_c =
[
    [ "Controllers", "namespace_game_list_m_v_c_1_1_controllers.html", "namespace_game_list_m_v_c_1_1_controllers" ],
    [ "Migrations", "namespace_game_list_m_v_c_1_1_migrations.html", "namespace_game_list_m_v_c_1_1_migrations" ],
    [ "Models", "namespace_game_list_m_v_c_1_1_models.html", "namespace_game_list_m_v_c_1_1_models" ],
    [ "Program", "class_game_list_m_v_c_1_1_program.html", null ],
    [ "Startup", "class_game_list_m_v_c_1_1_startup.html", "class_game_list_m_v_c_1_1_startup" ]
];