var dir_cd7daad1f4931fe989e76b93af2a0fb9 =
[
    [ "netcoreapp3.1", "dir_3d67544236ff31f96660d4ab818ec7a8.html", "dir_3d67544236ff31f96660d4ab818ec7a8" ]
];