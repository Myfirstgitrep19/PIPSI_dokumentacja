var namespaces_dup =
[
    [ "GameListMVC", "namespace_game_list_m_v_c.html", "namespace_game_list_m_v_c" ]
];