var dir_7f83177b967bc63f2451da2ec734c499 =
[
    [ "Controllers", "dir_bee5369abfcf2f1fd7b69af8c46fdfee.html", "dir_bee5369abfcf2f1fd7b69af8c46fdfee" ],
    [ "Migrations", "dir_8797c9183791cb1fe97175c12f393ce8.html", "dir_8797c9183791cb1fe97175c12f393ce8" ],
    [ "Models", "dir_62f95062b6808e798c869e33b99340c5.html", "dir_62f95062b6808e798c869e33b99340c5" ],
    [ "obj", "dir_023b94c8dca1fac9a4cf31ef38174ac0.html", "dir_023b94c8dca1fac9a4cf31ef38174ac0" ],
    [ "wwwroot", "dir_303398e9e98a05217ec3a153740deaf8.html", "dir_303398e9e98a05217ec3a153740deaf8" ],
    [ "Program.cs", "_program_8cs.html", [
      [ "Program", "class_game_list_m_v_c_1_1_program.html", null ]
    ] ],
    [ "Startup.cs", "_startup_8cs.html", [
      [ "Startup", "class_game_list_m_v_c_1_1_startup.html", "class_game_list_m_v_c_1_1_startup" ]
    ] ]
];