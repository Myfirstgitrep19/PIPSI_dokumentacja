var class_game_list_m_v_c_1_1_models_1_1_error_view_model =
[
    [ "ShowRequestId", "class_game_list_m_v_c_1_1_models_1_1_error_view_model.html#ad2b2c0b7e54315b4ecfbcd1f6e423395", null ],
    [ "RequestId", "class_game_list_m_v_c_1_1_models_1_1_error_view_model.html#a461b2b95b88a752c031dfd2c516d87c5", null ]
];