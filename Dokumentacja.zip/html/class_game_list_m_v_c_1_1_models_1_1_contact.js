var class_game_list_m_v_c_1_1_models_1_1_contact =
[
    [ "ContactEmail", "class_game_list_m_v_c_1_1_models_1_1_contact.html#a3fe16689a78f32c068d31068c9cd3330", null ],
    [ "ContactLastName", "class_game_list_m_v_c_1_1_models_1_1_contact.html#ad5a89d1714cef5e6a623b9ec6b9a328e", null ],
    [ "ContactMessage", "class_game_list_m_v_c_1_1_models_1_1_contact.html#a988c06f208a27569de3fec1efd72397c", null ],
    [ "ContactName", "class_game_list_m_v_c_1_1_models_1_1_contact.html#a9258277bc9e15b1b68b79538d2953184", null ],
    [ "ContactSubject", "class_game_list_m_v_c_1_1_models_1_1_contact.html#a29836dd2989267c309fd6f30c1a2b519", null ],
    [ "Id", "class_game_list_m_v_c_1_1_models_1_1_contact.html#a6c983b898ffd94faead9fe148709b8ec", null ]
];