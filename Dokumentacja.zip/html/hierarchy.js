var hierarchy =
[
    [ "GameListMVC.Models.Contact", "class_game_list_m_v_c_1_1_models_1_1_contact.html", null ],
    [ "Controller", null, [
      [ "GameListMVC.Controllers.ContactsController", "class_game_list_m_v_c_1_1_controllers_1_1_contacts_controller.html", null ],
      [ "GameListMVC.Controllers.GamesController", "class_game_list_m_v_c_1_1_controllers_1_1_games_controller.html", null ],
      [ "GameListMVC.Controllers.HomeController", "class_game_list_m_v_c_1_1_controllers_1_1_home_controller.html", null ],
      [ "GameListMVC.Controllers.UsersController", "class_game_list_m_v_c_1_1_controllers_1_1_users_controller.html", null ]
    ] ],
    [ "DbContext", null, [
      [ "GameListMVC.Models.ApplicationDbContext", "class_game_list_m_v_c_1_1_models_1_1_application_db_context.html", null ]
    ] ],
    [ "GameListMVC.Models.ErrorViewModel", "class_game_list_m_v_c_1_1_models_1_1_error_view_model.html", null ],
    [ "GameListMVC.Models.Game", "class_game_list_m_v_c_1_1_models_1_1_game.html", null ],
    [ "Migration", null, [
      [ "GameListMVC.Migrations.AddGameToDb", "class_game_list_m_v_c_1_1_migrations_1_1_add_game_to_db.html", null ],
      [ "GameListMVC.Migrations.Contacts", "class_game_list_m_v_c_1_1_migrations_1_1_contacts.html", null ]
    ] ],
    [ "ModelSnapshot", null, [
      [ "GameListMVC.Migrations.ApplicationDbContextModelSnapshot", "class_game_list_m_v_c_1_1_migrations_1_1_application_db_context_model_snapshot.html", null ]
    ] ],
    [ "GameListMVC.Program", "class_game_list_m_v_c_1_1_program.html", null ],
    [ "GameListMVC.Startup", "class_game_list_m_v_c_1_1_startup.html", null ],
    [ "GameListMVC.Models.User", "class_game_list_m_v_c_1_1_models_1_1_user.html", null ]
];