var class_game_list_m_v_c_1_1_models_1_1_game =
[
    [ "gameGenre", "class_game_list_m_v_c_1_1_models_1_1_game.html#add9c72b6bdec936fdf71e6e1ce01f604", null ],
    [ "gameTitle", "class_game_list_m_v_c_1_1_models_1_1_game.html#abb8304848a0d164f7d364265f417e791", null ],
    [ "gameYear", "class_game_list_m_v_c_1_1_models_1_1_game.html#a8e80fc6cb656d659bc98bbc691e8bfd1", null ],
    [ "Id", "class_game_list_m_v_c_1_1_models_1_1_game.html#aa23a81dd97f202f9d7cba3c3fd93dc97", null ]
];