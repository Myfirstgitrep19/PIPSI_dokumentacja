var class_game_list_m_v_c_1_1_models_1_1_user =
[
    [ "Email", "class_game_list_m_v_c_1_1_models_1_1_user.html#a90effbf725d36763b68e06ab5cdc322c", null ],
    [ "ID", "class_game_list_m_v_c_1_1_models_1_1_user.html#a9bba644f4e82cbea2cb084d7d8a269b6", null ],
    [ "Lastname", "class_game_list_m_v_c_1_1_models_1_1_user.html#a32a69f3df311026097fd9ec5e387f3f5", null ],
    [ "Login", "class_game_list_m_v_c_1_1_models_1_1_user.html#a3afc5160e4d30279fe4d789b24fc3c30", null ],
    [ "Name", "class_game_list_m_v_c_1_1_models_1_1_user.html#a0b5c2fd5f6e142d5ba74aefe6e6a57f1", null ],
    [ "Password", "class_game_list_m_v_c_1_1_models_1_1_user.html#a3ef54fa1effa5f4cccb4a83ed6f20992", null ]
];