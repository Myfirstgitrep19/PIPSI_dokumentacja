var class_game_list_m_v_c_1_1_controllers_1_1_games_controller =
[
    [ "GamesController", "class_game_list_m_v_c_1_1_controllers_1_1_games_controller.html#aac91dd42813d0b96593d9906992f3656", null ],
    [ "Delete", "class_game_list_m_v_c_1_1_controllers_1_1_games_controller.html#af84ba79c4c7bb78e2b0a8d61417a7567", null ],
    [ "GetAll", "class_game_list_m_v_c_1_1_controllers_1_1_games_controller.html#adc5255f35ea0e923b61d79caef225e86", null ],
    [ "Index", "class_game_list_m_v_c_1_1_controllers_1_1_games_controller.html#a39be80106321b9ad4161471e20fa7b4a", null ],
    [ "Upsert", "class_game_list_m_v_c_1_1_controllers_1_1_games_controller.html#ac0b2f7e2de6c363e4e4fc1a85adbcc65", null ],
    [ "Upsert", "class_game_list_m_v_c_1_1_controllers_1_1_games_controller.html#a13b8e12f70d35d675653e73e95d8eef2", null ],
    [ "_db", "class_game_list_m_v_c_1_1_controllers_1_1_games_controller.html#a274263040bab1a099c34d7aeb9a905ff", null ],
    [ "Game", "class_game_list_m_v_c_1_1_controllers_1_1_games_controller.html#a835107501d2d8969230c044d4e59fd63", null ]
];