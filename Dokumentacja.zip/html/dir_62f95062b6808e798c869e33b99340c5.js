var dir_62f95062b6808e798c869e33b99340c5 =
[
    [ "ApplicationDbContext.cs", "_application_db_context_8cs.html", [
      [ "ApplicationDbContext", "class_game_list_m_v_c_1_1_models_1_1_application_db_context.html", "class_game_list_m_v_c_1_1_models_1_1_application_db_context" ]
    ] ],
    [ "Contact.cs", "_contact_8cs.html", [
      [ "Contact", "class_game_list_m_v_c_1_1_models_1_1_contact.html", "class_game_list_m_v_c_1_1_models_1_1_contact" ]
    ] ],
    [ "ErrorViewModel.cs", "_error_view_model_8cs.html", [
      [ "ErrorViewModel", "class_game_list_m_v_c_1_1_models_1_1_error_view_model.html", "class_game_list_m_v_c_1_1_models_1_1_error_view_model" ]
    ] ],
    [ "Game.cs", "_game_8cs.html", [
      [ "Game", "class_game_list_m_v_c_1_1_models_1_1_game.html", "class_game_list_m_v_c_1_1_models_1_1_game" ]
    ] ],
    [ "User.cs", "_user_8cs.html", [
      [ "User", "class_game_list_m_v_c_1_1_models_1_1_user.html", "class_game_list_m_v_c_1_1_models_1_1_user" ]
    ] ]
];