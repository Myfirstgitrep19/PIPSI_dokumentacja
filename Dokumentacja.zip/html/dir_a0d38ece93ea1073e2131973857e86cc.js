var dir_a0d38ece93ea1073e2131973857e86cc =
[
    [ "OneDrive - studenci.pwsz.legnica.edu.pl", "dir_a486790a956d23e13ae0b8591983005d.html", "dir_a486790a956d23e13ae0b8591983005d" ]
];