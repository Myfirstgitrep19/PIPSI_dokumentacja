var class_game_list_m_v_c_1_1_startup =
[
    [ "Startup", "class_game_list_m_v_c_1_1_startup.html#aa1d1a007542ea73897f94fde679883d7", null ],
    [ "Configure", "class_game_list_m_v_c_1_1_startup.html#a31278e54cc91af7483f3fbe81ecfb97e", null ],
    [ "ConfigureServices", "class_game_list_m_v_c_1_1_startup.html#ab3c63a83f6a972fc661e43101170a427", null ],
    [ "Configuration", "class_game_list_m_v_c_1_1_startup.html#ad4a59e8a2db7f3ad2df8cb3a37a86afe", null ]
];