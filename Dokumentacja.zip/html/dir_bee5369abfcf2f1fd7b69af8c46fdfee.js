var dir_bee5369abfcf2f1fd7b69af8c46fdfee =
[
    [ "ContactsController.cs", "_contacts_controller_8cs.html", [
      [ "ContactsController", "class_game_list_m_v_c_1_1_controllers_1_1_contacts_controller.html", "class_game_list_m_v_c_1_1_controllers_1_1_contacts_controller" ]
    ] ],
    [ "GamesController.cs", "_games_controller_8cs.html", [
      [ "GamesController", "class_game_list_m_v_c_1_1_controllers_1_1_games_controller.html", "class_game_list_m_v_c_1_1_controllers_1_1_games_controller" ]
    ] ],
    [ "HomeController.cs", "_home_controller_8cs.html", [
      [ "HomeController", "class_game_list_m_v_c_1_1_controllers_1_1_home_controller.html", "class_game_list_m_v_c_1_1_controllers_1_1_home_controller" ]
    ] ],
    [ "UsersController.cs", "_users_controller_8cs.html", [
      [ "UsersController", "class_game_list_m_v_c_1_1_controllers_1_1_users_controller.html", "class_game_list_m_v_c_1_1_controllers_1_1_users_controller" ]
    ] ]
];