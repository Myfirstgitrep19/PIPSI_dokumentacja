var class_game_list_m_v_c_1_1_migrations_1_1_add_game_to_db =
[
    [ "BuildTargetModel", "class_game_list_m_v_c_1_1_migrations_1_1_add_game_to_db.html#aecbf9976385b275ee6cd1947d9068542", null ],
    [ "Down", "class_game_list_m_v_c_1_1_migrations_1_1_add_game_to_db.html#a369435fcc1a6ec25a49c44d802ce457e", null ],
    [ "Up", "class_game_list_m_v_c_1_1_migrations_1_1_add_game_to_db.html#a174347bd9c2d5880e350f3406cd4933d", null ]
];