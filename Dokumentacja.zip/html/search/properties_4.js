var searchData=
[
  ['lastname_216',['Lastname',['../class_game_list_m_v_c_1_1_models_1_1_user.html#a32a69f3df311026097fd9ec5e387f3f5',1,'GameListMVC::Models::User']]],
  ['login_217',['Login',['../class_game_list_m_v_c_1_1_models_1_1_user.html#a3afc5160e4d30279fe4d789b24fc3c30',1,'GameListMVC::Models::User']]]
];
