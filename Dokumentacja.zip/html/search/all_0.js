var searchData=
[
  ['20200604215126_5faddgametodb_2ecs_0',['20200604215126_AddGameToDb.cs',['../20200604215126___add_game_to_db_8cs.html',1,'']]],
  ['20200604215126_5faddgametodb_2edesigner_2ecs_1',['20200604215126_AddGameToDb.Designer.cs',['../20200604215126___add_game_to_db_8_designer_8cs.html',1,'']]],
  ['20200605183804_5fcontacts_2ecs_2',['20200605183804_Contacts.cs',['../20200605183804___contacts_8cs.html',1,'']]],
  ['20200605183804_5fcontacts_2edesigner_2ecs_3',['20200605183804_contacts.Designer.cs',['../20200605183804__contacts_8_designer_8cs.html',1,'']]]
];
