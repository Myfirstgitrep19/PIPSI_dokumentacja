var searchData=
[
  ['startup_117',['Startup',['../class_game_list_m_v_c_1_1_startup.html',1,'GameListMVC']]]
];
