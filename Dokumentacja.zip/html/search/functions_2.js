var searchData=
[
  ['configure_147',['Configure',['../class_game_list_m_v_c_1_1_startup.html#a31278e54cc91af7483f3fbe81ecfb97e',1,'GameListMVC::Startup']]],
  ['configureservices_148',['ConfigureServices',['../class_game_list_m_v_c_1_1_startup.html#ab3c63a83f6a972fc661e43101170a427',1,'GameListMVC::Startup']]],
  ['contactscontroller_149',['ContactsController',['../class_game_list_m_v_c_1_1_controllers_1_1_contacts_controller.html#ac75900d2a7e2894dab31a7aa6e71f4c1',1,'GameListMVC::Controllers::ContactsController']]],
  ['copyright_150',['Copyright',['../jquery-validation-unobtrusive_2_l_i_c_e_n_s_e_8txt.html#abc699d68d8f1db8770139a88435d2061',1,'LICENSE.txt']]],
  ['create_151',['Create',['../class_game_list_m_v_c_1_1_controllers_1_1_contacts_controller.html#a50573f8efb5465094c6917f30223a109',1,'GameListMVC.Controllers.ContactsController.Create()'],['../class_game_list_m_v_c_1_1_controllers_1_1_contacts_controller.html#a47ba581466cf76c992eae8db0ce4f4a6',1,'GameListMVC.Controllers.ContactsController.Create([Bind(&quot;Id,ContactName,ContactLastName,ContactEmail,ContactMessage&quot;)] Contact contact)'],['../class_game_list_m_v_c_1_1_controllers_1_1_users_controller.html#ac16f501045da0a647a41fa23f3dd83e0',1,'GameListMVC.Controllers.UsersController.Create()'],['../class_game_list_m_v_c_1_1_controllers_1_1_users_controller.html#a46cb6dbb55ea4e6be8c5474adac61c94',1,'GameListMVC.Controllers.UsersController.Create([Bind(&quot;ID,Login,Password,Name,Lastname,Email&quot;)] User user)']]],
  ['createhostbuilder_152',['CreateHostBuilder',['../class_game_list_m_v_c_1_1_program.html#a4701113707a0fed888481cd7c80c3eae',1,'GameListMVC::Program']]]
];
