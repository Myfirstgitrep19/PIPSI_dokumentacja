var searchData=
[
  ['name_218',['Name',['../class_game_list_m_v_c_1_1_models_1_1_user.html#a0b5c2fd5f6e142d5ba74aefe6e6a57f1',1,'GameListMVC::Models::User']]]
];
