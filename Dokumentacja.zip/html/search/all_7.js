var searchData=
[
  ['controllers_46',['Controllers',['../namespace_game_list_m_v_c_1_1_controllers.html',1,'GameListMVC']]],
  ['game_47',['Game',['../class_game_list_m_v_c_1_1_models_1_1_game.html',1,'GameListMVC.Models.Game'],['../class_game_list_m_v_c_1_1_controllers_1_1_games_controller.html#a835107501d2d8969230c044d4e59fd63',1,'GameListMVC.Controllers.GamesController.Game()']]],
  ['game_2ecs_48',['Game.cs',['../_game_8cs.html',1,'']]],
  ['gamegenre_49',['gameGenre',['../class_game_list_m_v_c_1_1_models_1_1_game.html#add9c72b6bdec936fdf71e6e1ce01f604',1,'GameListMVC::Models::Game']]],
  ['gamelistmvc_50',['GameListMVC',['../namespace_game_list_m_v_c.html',1,'']]],
  ['gamelistmvc_2eassemblyinfo_2ecs_51',['GameListMVC.AssemblyInfo.cs',['../_game_list_m_v_c_8_assembly_info_8cs.html',1,'']]],
  ['games_52',['Games',['../class_game_list_m_v_c_1_1_models_1_1_application_db_context.html#a1ce0a14c28d8fcbb8705840ae7b1275b',1,'GameListMVC::Models::ApplicationDbContext']]],
  ['gamescontroller_53',['GamesController',['../class_game_list_m_v_c_1_1_controllers_1_1_games_controller.html',1,'GameListMVC.Controllers.GamesController'],['../class_game_list_m_v_c_1_1_controllers_1_1_games_controller.html#aac91dd42813d0b96593d9906992f3656',1,'GameListMVC.Controllers.GamesController.GamesController()']]],
  ['gamescontroller_2ecs_54',['GamesController.cs',['../_games_controller_8cs.html',1,'']]],
  ['gametitle_55',['gameTitle',['../class_game_list_m_v_c_1_1_models_1_1_game.html#abb8304848a0d164f7d364265f417e791',1,'GameListMVC::Models::Game']]],
  ['gameyear_56',['gameYear',['../class_game_list_m_v_c_1_1_models_1_1_game.html#a8e80fc6cb656d659bc98bbc691e8bfd1',1,'GameListMVC::Models::Game']]],
  ['getall_57',['GetAll',['../class_game_list_m_v_c_1_1_controllers_1_1_games_controller.html#adc5255f35ea0e923b61d79caef225e86',1,'GameListMVC::Controllers::GamesController']]],
  ['migrations_58',['Migrations',['../namespace_game_list_m_v_c_1_1_migrations.html',1,'GameListMVC']]],
  ['models_59',['Models',['../namespace_game_list_m_v_c_1_1_models.html',1,'GameListMVC']]]
];
