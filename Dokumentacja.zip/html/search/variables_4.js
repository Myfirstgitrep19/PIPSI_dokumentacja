var searchData=
[
  ['http_184',['http',['../jquery-validation-unobtrusive_2_l_i_c_e_n_s_e_8txt.html#a6d3eab50ac31e5cfcbf63fa745e12872',1,'LICENSE.txt']]],
  ['https_185',['https',['../jquery_2_l_i_c_e_n_s_e_8txt.html#a9e1a04b58cc473796394d8f562288114',1,'LICENSE.txt']]]
];
