var searchData=
[
  ['privacy_168',['Privacy',['../class_game_list_m_v_c_1_1_controllers_1_1_home_controller.html#a767008da02ed64618677db9bda5475e5',1,'GameListMVC::Controllers::HomeController']]]
];
