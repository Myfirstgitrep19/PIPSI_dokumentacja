var searchData=
[
  ['merchantability_189',['MERCHANTABILITY',['../jquery_2_l_i_c_e_n_s_e_8txt.html#ae1a2ea351a94d82d80366dcd7f796043',1,'LICENSE.txt']]],
  ['merge_190',['merge',['../jquery_2_l_i_c_e_n_s_e_8txt.html#a42e96c49886563ec01e1a74f17d128b2',1,'LICENSE.txt']]],
  ['modify_191',['modify',['../jquery_2_l_i_c_e_n_s_e_8txt.html#a16d4e10cdf4a5bfb644623888d88964c',1,'LICENSE.txt']]]
];
