var searchData=
[
  ['game_210',['Game',['../class_game_list_m_v_c_1_1_controllers_1_1_games_controller.html#a835107501d2d8969230c044d4e59fd63',1,'GameListMVC::Controllers::GamesController']]],
  ['gamegenre_211',['gameGenre',['../class_game_list_m_v_c_1_1_models_1_1_game.html#add9c72b6bdec936fdf71e6e1ce01f604',1,'GameListMVC::Models::Game']]],
  ['games_212',['Games',['../class_game_list_m_v_c_1_1_models_1_1_application_db_context.html#a1ce0a14c28d8fcbb8705840ae7b1275b',1,'GameListMVC::Models::ApplicationDbContext']]],
  ['gametitle_213',['gameTitle',['../class_game_list_m_v_c_1_1_models_1_1_game.html#abb8304848a0d164f7d364265f417e791',1,'GameListMVC::Models::Game']]],
  ['gameyear_214',['gameYear',['../class_game_list_m_v_c_1_1_models_1_1_game.html#a8e80fc6cb656d659bc98bbc691e8bfd1',1,'GameListMVC::Models::Game']]]
];
