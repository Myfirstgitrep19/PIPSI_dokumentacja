var searchData=
[
  ['files_44',['files',['../jquery_2_l_i_c_e_n_s_e_8txt.html#a35cf543899fd710ec05aaa62e2804ed9',1,'LICENSE.txt']]],
  ['from_45',['FROM',['../jquery_2_l_i_c_e_n_s_e_8txt.html#ad20dada78dc01ff9f6a9eba39b737a79',1,'LICENSE.txt']]]
];
