var searchData=
[
  ['lastname_68',['Lastname',['../class_game_list_m_v_c_1_1_models_1_1_user.html#a32a69f3df311026097fd9ec5e387f3f5',1,'GameListMVC::Models::User']]],
  ['liability_69',['LIABILITY',['../jquery_2_l_i_c_e_n_s_e_8txt.html#a30cee5511dfd3ad583865ab8a6c201fc',1,'LICENSE.txt']]],
  ['license_2emd_70',['LICENSE.md',['../_l_i_c_e_n_s_e_8md.html',1,'']]],
  ['license_2etxt_71',['LICENSE.txt',['../jquery_2_l_i_c_e_n_s_e_8txt.html',1,'(Global Namespace)'],['../jquery-validation-unobtrusive_2_l_i_c_e_n_s_e_8txt.html',1,'(Global Namespace)']]],
  ['login_72',['Login',['../class_game_list_m_v_c_1_1_models_1_1_user.html#a3afc5160e4d30279fe4d789b24fc3c30',1,'GameListMVC.Models.User.Login()'],['../class_game_list_m_v_c_1_1_controllers_1_1_users_controller.html#aeaaac1c74de8d5e10438475fa89fa540',1,'GameListMVC.Controllers.UsersController.Login()']]],
  ['logoutuser_73',['LogoutUser',['../class_game_list_m_v_c_1_1_controllers_1_1_users_controller.html#a4ae2374df27e3f1504805deec3da4e81',1,'GameListMVC::Controllers::UsersController']]]
];
