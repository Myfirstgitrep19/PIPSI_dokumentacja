var searchData=
[
  ['gamescontroller_160',['GamesController',['../class_game_list_m_v_c_1_1_controllers_1_1_games_controller.html#aac91dd42813d0b96593d9906992f3656',1,'GameListMVC::Controllers::GamesController']]],
  ['getall_161',['GetAll',['../class_game_list_m_v_c_1_1_controllers_1_1_games_controller.html#adc5255f35ea0e923b61d79caef225e86',1,'GameListMVC::Controllers::GamesController']]]
];
