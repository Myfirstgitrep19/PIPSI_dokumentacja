var searchData=
[
  ['user_118',['User',['../class_game_list_m_v_c_1_1_models_1_1_user.html',1,'GameListMVC::Models']]],
  ['userscontroller_119',['UsersController',['../class_game_list_m_v_c_1_1_controllers_1_1_users_controller.html',1,'GameListMVC::Controllers']]]
];
