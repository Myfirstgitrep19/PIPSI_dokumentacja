var searchData=
[
  ['basis_175',['BASIS',['../jquery-validation-unobtrusive_2_l_i_c_e_n_s_e_8txt.html#a7481bdf69521f23e12265ac712583b87',1,'LICENSE.txt']]]
];
