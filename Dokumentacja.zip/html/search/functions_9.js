var searchData=
[
  ['login_164',['Login',['../class_game_list_m_v_c_1_1_controllers_1_1_users_controller.html#aeaaac1c74de8d5e10438475fa89fa540',1,'GameListMVC::Controllers::UsersController']]],
  ['logoutuser_165',['LogoutUser',['../class_game_list_m_v_c_1_1_controllers_1_1_users_controller.html#a4ae2374df27e3f1504805deec3da4e81',1,'GameListMVC::Controllers::UsersController']]]
];
