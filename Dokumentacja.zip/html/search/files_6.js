var searchData=
[
  ['license_2emd_137',['LICENSE.md',['../_l_i_c_e_n_s_e_8md.html',1,'']]],
  ['license_2etxt_138',['LICENSE.txt',['../jquery_2_l_i_c_e_n_s_e_8txt.html',1,'(Global Namespace)'],['../jquery-validation-unobtrusive_2_l_i_c_e_n_s_e_8txt.html',1,'(Global Namespace)']]]
];
