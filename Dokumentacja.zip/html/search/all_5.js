var searchData=
[
  ['edit_39',['Edit',['../class_game_list_m_v_c_1_1_controllers_1_1_contacts_controller.html#ad14925850a7ed408ea0afba350de0df7',1,'GameListMVC.Controllers.ContactsController.Edit(int? id)'],['../class_game_list_m_v_c_1_1_controllers_1_1_contacts_controller.html#ac1743ee795025acc648671c7086da229',1,'GameListMVC.Controllers.ContactsController.Edit(int id, [Bind(&quot;Id,ContactName,ContactLastName,ContactEmail,ContactMessage&quot;)] Contact contact)'],['../class_game_list_m_v_c_1_1_controllers_1_1_users_controller.html#ae3d10a6592261f83eefe68d842e3c0ce',1,'GameListMVC.Controllers.UsersController.Edit(int? id)'],['../class_game_list_m_v_c_1_1_controllers_1_1_users_controller.html#aa1c4f6782ff4225bc196cb64786afefa',1,'GameListMVC.Controllers.UsersController.Edit(int id, [Bind(&quot;ID,Login,Password,Name,Lastname,Email&quot;)] User user)']]],
  ['email_40',['Email',['../class_game_list_m_v_c_1_1_models_1_1_user.html#a90effbf725d36763b68e06ab5cdc322c',1,'GameListMVC::Models::User']]],
  ['error_41',['Error',['../class_game_list_m_v_c_1_1_controllers_1_1_home_controller.html#a4dd0646dcbc13a27bf34069f19b8a06a',1,'GameListMVC::Controllers::HomeController']]],
  ['errorviewmodel_42',['ErrorViewModel',['../class_game_list_m_v_c_1_1_models_1_1_error_view_model.html',1,'GameListMVC::Models']]],
  ['errorviewmodel_2ecs_43',['ErrorViewModel.cs',['../_error_view_model_8cs.html',1,'']]]
];
