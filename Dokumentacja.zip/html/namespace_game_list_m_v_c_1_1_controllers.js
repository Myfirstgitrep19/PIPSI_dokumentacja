var namespace_game_list_m_v_c_1_1_controllers =
[
    [ "ContactsController", "class_game_list_m_v_c_1_1_controllers_1_1_contacts_controller.html", "class_game_list_m_v_c_1_1_controllers_1_1_contacts_controller" ],
    [ "GamesController", "class_game_list_m_v_c_1_1_controllers_1_1_games_controller.html", "class_game_list_m_v_c_1_1_controllers_1_1_games_controller" ],
    [ "HomeController", "class_game_list_m_v_c_1_1_controllers_1_1_home_controller.html", "class_game_list_m_v_c_1_1_controllers_1_1_home_controller" ],
    [ "UsersController", "class_game_list_m_v_c_1_1_controllers_1_1_users_controller.html", "class_game_list_m_v_c_1_1_controllers_1_1_users_controller" ]
];