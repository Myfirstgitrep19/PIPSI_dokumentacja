var class_game_list_m_v_c_1_1_controllers_1_1_home_controller =
[
    [ "HomeController", "class_game_list_m_v_c_1_1_controllers_1_1_home_controller.html#ae318806d3859d9d4c101f6564eaa4889", null ],
    [ "Error", "class_game_list_m_v_c_1_1_controllers_1_1_home_controller.html#a4dd0646dcbc13a27bf34069f19b8a06a", null ],
    [ "Index", "class_game_list_m_v_c_1_1_controllers_1_1_home_controller.html#abe234d5ca27769188eca88790d3a2760", null ],
    [ "Privacy", "class_game_list_m_v_c_1_1_controllers_1_1_home_controller.html#a767008da02ed64618677db9bda5475e5", null ],
    [ "_logger", "class_game_list_m_v_c_1_1_controllers_1_1_home_controller.html#a9d405d7d97be95701026cadf139f8240", null ]
];